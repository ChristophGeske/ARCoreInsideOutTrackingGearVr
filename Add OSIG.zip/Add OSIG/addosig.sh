#!/bin/bash

# Created by T-bond
# https://t-bond.hu

APK=$1
APKNAME="${APK%.*}"
java -jar apktool.jar -f d "$APK"
cp oculussig* "$APKNAME/assets"
java -jar apktool.jar b "$APKNAME" new.apk
rm "$APK"
cp "$APKNAME/dist/$APK" "$APK"
java -jar signapk.jar certificate.pem key.pk8 "$APK" $APKNAME"_osig.apk"
rm -rf "$APKNAME"
