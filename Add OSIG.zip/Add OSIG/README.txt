Places your OSIG file in an .APK, to enable GearVR.


Instructions:

1. Get your OSIG file from https://dashboard.oculus.com/tools/osig-generator

2. Rename it to 'oculussig'

3. Run 'AddOSIG.bat APK_file_name' 
where 'APK_file_name' is the desired .APK file to place the OSIG file in