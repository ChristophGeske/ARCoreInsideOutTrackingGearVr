Places your OSIG file in an .APK, to enable GearVR.


Instructions:

1. Get your OSIG file from https://dashboard.oculus.com/tools/osig-generator and
  put next to the downloaded and extracted files.
2. Put your .apk file next to the OSIG file.

Windows:
    
    2. Rename it to 'oculussig'.
    3. Run 'addosig.bat APK_file_name' where 'APK_file_name' is
        the desired .APK file to place the OSIG file in
    

Linux:
    2. Run the `addosig.sh yourapk_here.apk` with your apk name replaced
    
    The tool will now put every file starting with: `oculussig` into the apk, so
    you can test it on multiple devices too.
